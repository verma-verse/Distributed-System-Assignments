    #include <queue>
    #include <vector>
    #include <iostream>
    using namespace std;
     
    #define PR 6
    using namespace std;
     
    int token_holder;
    // Description of the token
    class Token {
       public:
    	int id;				 // Id of the site having token
    	queue<int> token_q;	 // Token queue
    	int ln[PR];			 // Token Array for sequence no
    	void init()			 // Initializing token
    	{
    		id = 0;
    		for (int i = 0; i < PR; i++) {
    			ln[i] = 0;
    		}
    	}
     
    } token;
     
    // Description of each Site
    class Site {
       public:
    	int rn[PR];		// Siteâ€™s Array for sequence no.
    	bool exec;		// For checking whether site is executing
    	bool isreq;		// For checking whether site is  requesting
    	bool hastoken;	// For checking whether site has token
    	void init()		// Initializing sites
    	{
    		exec = 0;
    		isreq = 0;
    		hastoken = 0;
    		for (int i = 0; i < PR; i++) {
    			rn[i] = 0;
    		}
    	}
    	void req(int pid, int seqno);
     
    } site[PR];
     
    // For a site to execute request of site pid with sequenceno seqno
    void Site::req(int pid, int seqno) {
    	int i;
    	rn[pid] = max(rn[pid], seqno);
    	if (hastoken == 1) {
    		if (exec == 0 && token.ln[pid] + 1 == rn[pid]) {
    			hastoken = 0;
    			token_holder = pid;
    		} else if (token.ln[pid] + 1 == rn[pid]) {
    			token.token_q.push(pid);
    		}
    	}
    }
     
    // Initialize
    void initialize() {
    	int i;
    	token.init();
    	for (i = 0; i < PR; i++) {
    		site[i].init();
    	}
    }
     
    // For a site with id pid to request for C.S.
     
    void request(int pid) {
    	int i, seqno;
    	seqno = ++site[pid].rn[pid];
    	// Checking whether it has already requested
    	if (site[pid].isreq == 1 || site[pid].exec == 1) {
    		cout<<"SITE "<<pid<<" is already requesting \n";
    		return;
    	}
     
    	site[pid].isreq = 1;
    	// Checking if it has the token
    	if (token_holder == pid) {
    		site[pid].isreq = 0;
    		site[pid].exec = 1;
    		cout<<
    			"SITE "<<pid<<" already has the token and it enters the critical "
    			"section\n ";
    		return;
    	}
     
    	// Sending Request
    	if (token_holder != pid) {
    		for (i = 0; i < PR; i++) {
    			if (i != pid) site[i].req(pid, seqno);
    		}
    	}
     
    	// Checking if it has got the token
    	if (token_holder == pid) {
    		site[pid].hastoken = 1;
    		site[pid].exec = 1;
    		site[pid].isreq = 0;
    		cout<<"SITE "<<pid<<" gets the token and it enters the critical section\n";
    	} else {
    		cout<<
    			"SITE "<<token_holder<<" is currently executing the critical section \nSite "<<pid<<
    			"has placed its request\n ";
    	}
    }
     
    // For a site with id pid to request for C.S.
    void release(int pid) {
    	if (site[pid].exec != 1) {
    		cout<<"SITE "<<pid<<" is not currently executing the critical section \n";
    		return;
    	}
     
    	int i, siteid;
    	token.ln[pid] = site[pid].rn[pid];
    	site[pid].exec = 0;
    	cout<<"SITE "<<pid<<" releases the critical section\n";
    	// Checking if deffred requests are there by checking token queue
    	// And Passing the token if queue is non empty
    	if (!token.token_q.empty()) {
    		siteid = token.token_q.front();
    		token.token_q.pop();
    		token.id = siteid;
    		site[pid].hastoken = 0;
    		token_holder = siteid;
    		site[siteid].hastoken = 1;
    		site[siteid].exec = 1;
    		site[siteid].isreq = 0;
    		cout<<"SITE "<<siteid<<" gets the token and it enters the critical section\n";
    		return;
    	}
    	cout<<"SITE "<<pid<<" still has the token\n";
    }
     
    // Printing the state of the system
    void print() {
    	int i, j, k = 0;
    	queue<int> temp;
    	cout<<"TOKEN STATE :\n";
    	cout<<"TOKEN HOLDER : "<<token_holder<<"\n";
    	cout<<"TOKEN QUEUE : ";
    	if (token.token_q.empty()) {
    		cout<<"EMPTY";
    		j = 0;
    	} else {
    		j = token.token_q.size();
    	}
     
    	while (k < j) {
    		i = token.token_q.front();
    		token.token_q.pop();
    		token.token_q.push(i);
    		cout<<i<<" ";
    		k++;
    	}
     
    	cout<<"\n";
    	cout<<"TOKEN SEQ NO ARRAY : ";
    	for (i = 0; i < PR; i++) cout<<" "<<token.ln[i]<<" ";
    	cout<<"\n";
    	cout<<"SITES SEQ NO ARRAY : \n";
    	for (i = 0; i < PR; i++) {
    		cout<<" S "<<i<<" :";
    		for (j = 0; j < PR; j++) cout<<" "<<site[i].rn[j]<<" ";
    		cout<<"\n";
    	}
    }
     
    int main() {
    	int i, j, time, pid;
    	string str;
    	initialize();
    	token_holder = 0;
    	site[0].hastoken = 1;
    	time = 0;
    	cout << "THE NO OF SITES IN THE DISTRIBUTED SYSTEM ARE " << PR << endl;
    	cout << "INITIAL STATE\n" << endl;
	print();
    	cout<<"\n";
    	while (str != "OVER") {
    		cin >> str;
    		if (str == "REQ") {
    			cin >> pid;
    			cout << "EVENT :" << str << " " << pid << endl << endl;
    			request(pid);
			print();
    			cout<<"\n";
    		} else if (str == "REL") {
    			cin >> pid;
    			cout << "EVENT :" << str << " " << pid << endl << endl;
    			release(pid);
    			print();
    			cout<<"\n";
    		}
    	}
    }
